import pandas as pd

from scrapy.selector import Selector
from scrapy.http import Request
try:
    from scrapy.spider import Spider
except:
    from scrapy.spider import BaseSpider as Spider
from scrapy.contrib.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor as sle


from google_patent.items import *


class google_patentSpider(Spider):
    name = "google_patent"
    allowed_domains = ["google.com"]
    start_urls = [
        "http://patent.google.com/",
    ]

    def __init__(self, *args, **kwargs):
        rawData = pd.read_csv("./patent_zhuanli_id_list_new.csv", encoding='utf-8')
        self.keyword_list = rawData['patent_id']

    def start_requests(self):
        # for i in xrange(0, len(self.keyword_list)):
        for i in xrange(0, 1800000):
            id = self.keyword_list[i]
            clean_id = str(id).replace("(", "").replace(")", "")
            # id = u'CN103109181(A)'
            # id = u'US4446105A'
            url = 'https://patents.google.com/patent/%s/en' % (clean_id)

            yield Request(url,
                          meta={'keyword_id': id},
                          callback=self.get_info)

    def get_info(self, response):
        sel = Selector(response)
        item = google_patentItem()
        keyword_id = response.meta['keyword_id']

        item['keyword_id'] = keyword_id
        item['status'] = ",".join(sel.xpath('//span[@itemprop="status"]/text()').extract())
        item['inventor'] = ",".join(sel.xpath('//dd[@itemprop="inventor"]/text()').extract())
        item['application_number'] = ",".join(sel.xpath('//dd[@itemprop="applicationNumber"]/text()').extract())
        item['original_assignee'] = ",".join(sel.xpath('//dd[@itemprop="assigneeOriginal"]/text()').extract())
        item['current_assignee'] = ",".join(sel.xpath('//dd[@itemprop="assigneeCurrent"]/text()').extract())
        item['priority_date'] = ",".join(sel.xpath('//dd/time[@itemprop="priorityDate"]/text()').extract())
        item['filing_date'] = ",".join(sel.xpath('//dd/time[@itemprop="filingDate"]/text()').extract())
        item['publication_date'] = ",".join(sel.xpath('//dd/time[@itemprop="publicationDate"]/text()').extract())

        item['citations_publication_number'] = ",".join(sel.xpath('//tr[@itemprop="backwardReferences"]/td/a/span[@itemprop="publicationNumber"]/text()').extract())
        item['citations_priority_date'] = ",".join(sel.xpath('//tr[@itemprop="backwardReferences"]/td[@itemprop="priorityDate"]/text()').extract())
        item['citations_publication_date'] = ",".join(sel.xpath('//tr[@itemprop="backwardReferences"]/td[@itemprop="publicationDate"]/text()').extract())
        item['citations_assignee_original'] = ",".join(sel.xpath('//tr[@itemprop="backwardReferences"]/td[@itemprop="assigneeOriginal"]/text()').extract())

        item['cited_by_publication_number'] = ",".join(sel.xpath('//tr[@itemprop="forwardReferences"]/td/a/span[@itemprop="publicationNumber"]/text()').extract())
        item['cited_by_priority_date'] = ",".join(sel.xpath('//tr[@itemprop="forwardReferences"]/td[@itemprop="priorityDate"]/text()').extract())
        item['cited_by_publication_date'] = ",".join(sel.xpath('//tr[@itemprop="forwardReferences"]/td[@itemprop="publicationDate"]/text()').extract())
        item['cited_by_assignee_original'] = ",".join(sel.xpath('//tr[@itemprop="forwardReferences"]/td[@itemprop="assigneeOriginal"]/text()').extract())
        item['cited_by_title'] = ",".join(sel.xpath('//tr[@itemprop="forwardReferences"]/td[@itemprop="title"]/text()').extract())

        item['similar_documents_is_scholar'] = ",".join(sel.xpath('//tr[@itemprop="similarDocuments"]/td/meta[@itemprop="isScholar"]/@content').extract())
        item['similar_documents_scholar_id'] = ",".join(sel.xpath('//tr[@itemprop="similarDocuments"]/td/meta[@itemprop="scholarID"]/@content').extract())
        item['similar_documents_scholar_authors'] = ",".join(sel.xpath('//tr[@itemprop="similarDocuments"]/td/a/span[@itemprop="scholarAuthors"]/text()').extract())
        item['similar_documents_publication_date'] = ",".join(sel.xpath('//tr[@itemprop="similarDocuments"]/td/time[@itemprop="publicationDate"]/text()').extract())
        item['similar_documents_title'] = ",".join(sel.xpath('//tr[@itemprop="similarDocuments"]/td[@itemprop="title"]/text()').extract())

        item['legal_events_date'] = ",".join(sel.xpath('//tr[@itemprop="legalEvents"]/td/time[@itemprop="date"]/text()').extract())
        item['legal_events_code'] = ",".join(sel.xpath('//tr[@itemprop="legalEvents"]/td[@itemprop="code"]/text()').extract())
        item['legal_events_title'] = ",".join(sel.xpath('//tr[@itemprop="legalEvents"]/td[@itemprop="title"]/text()').extract())

        item['url'] = response.url

        yield item