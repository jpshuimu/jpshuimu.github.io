# Scrapy settings for google_patent project
#
# For simplicity, this file contains only the most important settings by
# default. All the other settings are documented here:
#
#     http://doc.scrapy.org/en/latest/topics/settings.html
#

import sys
import os
import time

from os.path import dirname
path = dirname(dirname(os.path.abspath(os.path.dirname(__file__))))
sys.path.append(path)

BOT_NAME = 'google_patent'

SPIDER_MODULES = ['google_patent.spiders']
NEWSPIDER_MODULE = 'google_patent.spiders'

# Crawl responsibly by identifying yourself (and your website) on the user-agent
#USER_AGENT = 'google_patent (+http://www.yourdomain.com)'

DOWNLOADER_MIDDLEWARES = {
   # 'misc.middleware.CustomHttpProxyMiddleware': 400,
    # 'misc.middleware.CustomUserAgentMiddleware': 401,
}


ITEM_PIPELINES = {
    'google_patent.pipelines.JsonWithEncodingPipeline': 300,
    # 'google_patent.pipelines.CSVPipeline': 299,
    #'google_patent.pipelines.RedisPipeline': 301,
}

LOG_LEVEL = 'INFO'

LOG_FILE = 'log/log_%s.txt' % (time.strftime('%Y%m%d_%X'))

COOKIES_ENABLES = False

DOWNLOAD_DELAY = 0
