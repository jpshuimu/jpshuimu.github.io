# Define here the models for your scraped items
#
# See documentation in:
# http://doc.scrapy.org/en/latest/topics/items.html

from scrapy.item import Item, Field

class google_patentItem(Item):
    keyword_id = Field()
    status = Field()
    inventor = Field()
    application_number = Field()
    original_assignee = Field()
    current_assignee = Field()
    priority_date = Field()
    filing_date = Field()
    publication_date = Field()

    citations_publication_number = Field()
    citations_priority_date = Field()
    citations_publication_date = Field()
    citations_assignee_original = Field()

    cited_by_publication_number = Field()
    cited_by_priority_date = Field()
    cited_by_publication_date = Field()
    cited_by_assignee_original = Field()
    cited_by_title = Field()

    similar_documents_is_scholar = Field()
    similar_documents_scholar_id = Field()
    similar_documents_scholar_authors = Field()
    similar_documents_publication_date = Field()
    similar_documents_title = Field()

    legal_events_date = Field()
    legal_events_code = Field()
    legal_events_title = Field()

    url = Field()

